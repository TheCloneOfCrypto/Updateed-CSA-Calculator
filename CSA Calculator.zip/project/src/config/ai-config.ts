export const AI_CONFIG = {
  openai: {
    apiKey: import.meta.env.VITE_OPENAI_API_KEY || '',
    model: 'gpt-3.5-turbo',
  },
  perplexity: {
    apiKey: import.meta.env.VITE_PERPLEXITY_API_KEY || '',
    model: 'mistral-7b-instruct',
  }
};