import React, { useState } from 'react';
import { getAISuggestions } from '../services/ai-service';

export default function APITest() {
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<string[]>([]);
  const [error, setError] = useState<string>('');

  const testAPI = async () => {
    setLoading(true);
    setError('');
    try {
      const result = await getAISuggestions(2.5, 3.0);
      setResponse(result.suggestions);
      if (result.error) {
        setError(result.error);
      }
    } catch (err) {
      setError('API test failed: ' + (err instanceof Error ? err.message : String(err)));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed top-4 right-4 z-50 bg-zinc-900/95 p-4 rounded-xl border border-zinc-800 shadow-xl w-80">
      <h2 className="text-lg font-semibold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-cyan-500">
        API Test Panel
      </h2>
      
      <button
        onClick={testAPI}
        className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 p-[2px] rounded-lg mb-4 transition-transform hover:scale-[0.99] active:scale-95"
      >
        <div className="bg-zinc-900 hover:bg-zinc-800 transition-colors px-4 py-2 rounded-lg">
          <span className="text-sm font-semibold text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-cyan-500">
            {loading ? 'Testing...' : 'Test Perplexity API'}
          </span>
        </div>
      </button>

      {error && (
        <div className="text-red-400 text-sm mb-4 p-2 bg-red-900/20 rounded-lg">
          {error}
        </div>
      )}

      {response.length > 0 && (
        <div className="text-zinc-300 text-sm space-y-2">
          <div className="font-semibold text-green-400 mb-2">API Response:</div>
          {response.map((suggestion, index) => (
            <p key={index} className="border-l-2 border-green-500/30 pl-2">
              {suggestion}
            </p>
          ))}
        </div>
      )}
    </div>
  );
}