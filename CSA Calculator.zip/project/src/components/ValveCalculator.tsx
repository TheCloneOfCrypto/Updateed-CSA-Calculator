import React, { useState } from 'react';
import InputField from './InputField';
import ResultDisplay from './ResultDisplay';
import { calculateValveCSA, calculatePortCSA, calculateMGV, calculateTaper } from '../utils/calculations';

interface ValidationError {
  field: string;
  message: string;
}

export default function ValveCalculator() {
  const [inputs, setInputs] = useState({
    valveDiameter: '',
    liftHeight: '',
    portDiameter: '',
    cfm: '',
  });

  const [results, setResults] = useState({
    valveCSA: 0,
    portCSA: 0,
    mgv: 0,
    taperAngle: 0,
  });

  const [errors, setErrors] = useState<ValidationError[]>([]);

  const validateInputs = (): ValidationError[] => {
    const errors: ValidationError[] = [];
    const values = {
      valveDiameter: parseFloat(inputs.valveDiameter),
      liftHeight: parseFloat(inputs.liftHeight),
      portDiameter: parseFloat(inputs.portDiameter),
      cfm: parseFloat(inputs.cfm),
    };

    if (!values.valveDiameter || values.valveDiameter <= 0) {
      errors.push({ field: 'valveDiameter', message: 'Valve diameter must be greater than 0' });
    }
    if (values.valveDiameter > 2.5) {
      errors.push({ field: 'valveDiameter', message: 'Valve diameter cannot exceed 2.5 inches' });
    }

    if (!values.liftHeight || values.liftHeight <= 0) {
      errors.push({ field: 'liftHeight', message: 'Lift height must be greater than 0' });
    }
    if (values.liftHeight > 1.5) {
      errors.push({ field: 'liftHeight', message: 'Lift height cannot exceed 1.5 inches' });
    }

    if (!values.portDiameter || values.portDiameter <= 0) {
      errors.push({ field: 'portDiameter', message: 'Port diameter must be greater than 0' });
    }
    if (values.portDiameter > 4) {
      errors.push({ field: 'portDiameter', message: 'Port diameter cannot exceed 4 inches' });
    }
    if (values.portDiameter <= values.valveDiameter) {
      errors.push({ field: 'portDiameter', message: 'Port diameter must be larger than valve diameter' });
    }

    if (!values.cfm || values.cfm <= 0) {
      errors.push({ field: 'cfm', message: 'Airflow must be greater than 0' });
    }

    return errors;
  };

  const handleCalculate = () => {
    const validationErrors = validateInputs();
    setErrors(validationErrors);

    if (validationErrors.length > 0) {
      return;
    }

    const values = {
      valveDiameter: parseFloat(inputs.valveDiameter) || 0,
      liftHeight: parseFloat(inputs.liftHeight) || 0,
      portDiameter: parseFloat(inputs.portDiameter) || 0,
      cfm: parseFloat(inputs.cfm) || 0,
    };

    try {
      const valveCSA = calculateValveCSA(values.valveDiameter, values.liftHeight);
      const portCSA = calculatePortCSA(values.portDiameter);
      const mgv = calculateMGV(values.cfm, valveCSA);
      const taperAngle = calculateTaper(values.portDiameter, values.valveDiameter);
      
      setResults({ valveCSA, portCSA, mgv, taperAngle });
      setErrors([]);
    } catch (error) {
      setErrors([{ field: 'calculation', message: 'An error occurred during calculation' }]);
    }
  };

  const getErrorForField = (field: string) => {
    return errors.find(error => error.field === field)?.message;
  };

  return (
    <div className="max-w-md mx-auto">
      <div className="bg-zinc-900/50 backdrop-blur-xl rounded-3xl shadow-2xl border border-zinc-800/50 p-6 md:p-8">
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-500 mb-2">
            Valve CSA Calculator
          </h1>
          <p className="text-zinc-400 text-xs">Automotive Performance Analysis</p>
        </div>

        <div className="space-y-4 mb-6">
          <div className="grid grid-cols-2 gap-3">
            <InputField
              label="Valve Diameter"
              value={inputs.valveDiameter}
              onChange={(value) => setInputs({ ...inputs, valveDiameter: value })}
              placeholder="2.5"
              max={2.5}
              unit="in"
              error={getErrorForField('valveDiameter')}
            />
            <InputField
              label="Lift Height"
              value={inputs.liftHeight}
              onChange={(value) => setInputs({ ...inputs, liftHeight: value })}
              placeholder="0.5"
              max={1.5}
              unit="in"
              error={getErrorForField('liftHeight')}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <InputField
              label="Port Diameter"
              value={inputs.portDiameter}
              onChange={(value) => setInputs({ ...inputs, portDiameter: value })}
              placeholder="4.0"
              max={4}
              unit="in"
              error={getErrorForField('portDiameter')}
            />
            <InputField
              label="Airflow"
              value={inputs.cfm}
              onChange={(value) => setInputs({ ...inputs, cfm: value })}
              placeholder="300"
              step={1}
              unit="CFM"
              error={getErrorForField('cfm')}
            />
          </div>
        </div>

        {getErrorForField('calculation') && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
            <p className="text-red-400 text-sm">{getErrorForField('calculation')}</p>
          </div>
        )}

        <button
          onClick={handleCalculate}
          className="w-full bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-500 p-[2px] rounded-xl mb-6 transition-transform hover:scale-[0.99] active:scale-95"
        >
          <div className="bg-zinc-900 hover:bg-zinc-800 transition-colors px-6 py-2.5 rounded-xl">
            <span className="text-lg font-semibold text-transparent bg-clip-text bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-500">
              Calculate
            </span>
          </div>
        </button>

        <ResultDisplay results={results} />
      </div>
    </div>
  );
}