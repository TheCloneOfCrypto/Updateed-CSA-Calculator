import React, { useEffect, useState } from 'react';
import { getAISuggestions } from '../services/ai-service';

interface AISuggestionsProps {
  targetCSA: number;
  currentCSA: number;
}

export default function AISuggestions({ targetCSA, currentCSA }: AISuggestionsProps) {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [error, setError] = useState<string | undefined>();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchSuggestions = async () => {
      if (!targetCSA || !currentCSA) {
        setSuggestions([]);
        setError(undefined);
        return;
      }

      setLoading(true);
      setError(undefined);

      try {
        const response = await getAISuggestions(currentCSA, targetCSA);
        setSuggestions(response.suggestions);
        setError(response.error);
      } catch (err) {
        setError('Failed to get suggestions. Please try again.');
        setSuggestions([]);
      } finally {
        setLoading(false);
      }
    };

    fetchSuggestions();
  }, [targetCSA, currentCSA]);

  if (!targetCSA || !currentCSA) return null;

  return (
    <div className="relative group mt-8">
      <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl opacity-20 group-hover:opacity-30 blur transition duration-200"></div>
      <div className="relative bg-zinc-900/80 p-4 rounded-xl border border-zinc-800">
        <h3 className="text-lg font-semibold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-cyan-500">
          AI Suggestions
        </h3>
        <div className="space-y-2 text-zinc-300">
          {loading ? (
            <p className="text-sm animate-pulse">Loading suggestions...</p>
          ) : error ? (
            <p className="text-sm text-red-400">{error}</p>
          ) : suggestions.length > 0 ? (
            suggestions.map((suggestion, index) => (
              <p key={index} className="text-sm">
                {suggestion}
              </p>
            ))
          ) : (
            <p className="text-sm text-zinc-400">No suggestions available</p>
          )}
        </div>
      </div>
    </div>
  );
}