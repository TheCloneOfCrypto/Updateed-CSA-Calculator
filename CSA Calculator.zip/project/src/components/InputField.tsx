import React from 'react';

interface InputFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  max?: number;
  step?: number;
  unit?: string;
  error?: string;
}

export default function InputField({ 
  label, 
  value, 
  onChange, 
  placeholder, 
  max, 
  step = 0.1, 
  unit,
  error
}: InputFieldProps) {
  return (
    <div className="space-y-1">
      <label className="block text-zinc-400 text-sm font-medium">{label}</label>
      <div className="relative group">
        <div className={`absolute -inset-0.5 rounded-lg blur transition duration-200 ${
          error 
            ? 'bg-red-500/20 opacity-100' 
            : 'bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-500 opacity-20 group-hover:opacity-30'
        }`}></div>
        <div className="relative">
          <input
            type="number"
            inputMode="decimal"
            pattern="[0-9]*"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            max={max}
            step={step}
            className={`w-full bg-zinc-900/80 text-white px-4 py-2.5 rounded-lg border ${
              error 
                ? 'border-red-500/50 focus:ring-red-500/50' 
                : 'border-zinc-700 focus:ring-amber-500/50'
            } focus:outline-none focus:ring-2 text-right pr-12`}
          />
          {unit && (
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-400 text-sm">
              {unit}
            </span>
          )}
        </div>
      </div>
      {error && (
        <p className="text-red-400 text-xs mt-1">{error}</p>
      )}
    </div>
  );
}