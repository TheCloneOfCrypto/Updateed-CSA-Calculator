import { AI_CONFIG } from '../config/ai-config';

interface AIResponse {
  suggestions: string[];
  error?: string;
}

export async function getAISuggestions(
  currentCSA: number,
  targetCSA: number
): Promise<AIResponse> {
  // Validate inputs
  if (!isFinite(currentCSA) || !isFinite(targetCSA)) {
    return {
      suggestions: [],
      error: 'Invalid input values provided'
    };
  }

  // Check API configuration
  if (!AI_CONFIG.perplexity.apiKey && !AI_CONFIG.openai.apiKey) {
    return {
      suggestions: generateLocalSuggestions(currentCSA, targetCSA),
      error: 'No API keys configured. Using local suggestions.'
    };
  }

  try {
    // Try Perplexity API first
    if (AI_CONFIG.perplexity.apiKey) {
      const perplexityResponse = await getPerplexitySuggestions(currentCSA, targetCSA);
      if (perplexityResponse.suggestions.length > 0) {
        return perplexityResponse;
      }
    }

    // Fallback to OpenAI if available
    if (AI_CONFIG.openai.apiKey) {
      const openAIResponse = await getOpenAISuggestions(currentCSA, targetCSA);
      if (openAIResponse.suggestions.length > 0) {
        return openAIResponse;
      }
    }

    // If both APIs fail or return no suggestions, use local fallback
    return {
      suggestions: generateLocalSuggestions(currentCSA, targetCSA),
      error: 'API responses were invalid. Using local suggestions.'
    };
  } catch (error) {
    console.error('AI API Error:', error);
    return {
      suggestions: generateLocalSuggestions(currentCSA, targetCSA),
      error: 'Failed to get AI suggestions. Using local suggestions.'
    };
  }
}

async function getPerplexitySuggestions(
  currentCSA: number,
  targetCSA: number
): Promise<AIResponse> {
  try {
    const response = await fetch('https://api.perplexity.ai/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${AI_CONFIG.perplexity.apiKey}`,
      },
      body: JSON.stringify({
        model: AI_CONFIG.perplexity.model,
        messages: [{
          role: 'system',
          content: 'You are an automotive engineering expert.'
        }, {
          role: 'user',
          content: `Provide 3-4 specific suggestions to ${
            targetCSA > currentCSA ? 'increase' : 'decrease'
          } the Cross-Sectional Area (CSA) from ${currentCSA.toFixed(2)} in² to ${targetCSA.toFixed(2)} in². Format each suggestion as a bullet point starting with "•".`
        }],
      }),
    });

    if (!response.ok) {
      throw new Error(`Perplexity API request failed: ${response.status}`);
    }

    const data = await response.json();
    
    if (!data?.choices?.[0]?.message?.content) {
      throw new Error('Invalid response format from Perplexity API');
    }

    const suggestions = data.choices[0].message.content
      .split('\n')
      .filter((line: string) => line.trim().startsWith('•'))
      .map((line: string) => line.trim());

    return { suggestions };
  } catch (error) {
    throw new Error(`Perplexity API error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

async function getOpenAISuggestions(
  currentCSA: number,
  targetCSA: number
): Promise<AIResponse> {
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${AI_CONFIG.openai.apiKey}`,
      },
      body: JSON.stringify({
        model: AI_CONFIG.openai.model,
        messages: [{
          role: 'system',
          content: 'You are an automotive engineering expert.'
        }, {
          role: 'user',
          content: `Provide 3-4 specific suggestions to ${
            targetCSA > currentCSA ? 'increase' : 'decrease'
          } the Cross-Sectional Area (CSA) from ${currentCSA.toFixed(2)} in² to ${targetCSA.toFixed(2)} in². Format each suggestion as a bullet point starting with "•".`
        }],
        temperature: 0.7,
        max_tokens: 200,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API request failed: ${response.status}`);
    }

    const data = await response.json();
    
    if (!data?.choices?.[0]?.message?.content) {
      throw new Error('Invalid response format from OpenAI API');
    }

    const suggestions = data.choices[0].message.content
      .split('\n')
      .filter((line: string) => line.trim().startsWith('•'))
      .map((line: string) => line.trim());

    return { suggestions };
  } catch (error) {
    throw new Error(`OpenAI API error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

function generateLocalSuggestions(currentCSA: number, targetCSA: number): string[] {
  const diff = targetCSA - currentCSA;
  
  if (Math.abs(diff) < 0.1) {
    return ["Your current configuration is optimal for your target CSA! 🎯"];
  }

  if (diff > 0) {
    return [
      "• Increase valve lift height for better flow characteristics",
      "• Consider using a larger valve diameter within manufacturer specs",
      "• Optimize valve stem design to reduce flow restrictions",
      "• Review port configuration for potential improvements"
    ];
  }

  return [
    "• Reduce valve lift height to decrease flow area",
    "• Consider using a smaller valve diameter if feasible",
    "• Adjust port configuration to match desired flow characteristics",
    "• Review valve guide design for optimal performance"
  ];
}